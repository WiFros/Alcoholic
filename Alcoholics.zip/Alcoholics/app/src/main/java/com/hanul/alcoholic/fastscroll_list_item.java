package com.hanul.alcoholic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class fastscroll_list_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fastscroll_list_item);
    }
}